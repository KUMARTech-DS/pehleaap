#!/usr/bin/env bash
set -Eeuo pipefail

# One-command GCP bootstrap + database + seed + app + NudgeBee.
# Required env vars are loaded from .env.deploy (never commit that file).
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ -f .env.deploy ]]; then set -a; source .env.deploy; set +a; fi
: "${PROJECT_ID:?Set PROJECT_ID in .env.deploy}"
: "${APP_DOMAIN:?Set APP_DOMAIN and point its DNS A record to the reserved IP (or set DNS_ZONE)}"
: "${SARVAM_API_KEY:?Set SARVAM_API_KEY}"
: "${FLAGSMITH_SERVER_KEY:?Set FLAGSMITH_SERVER_KEY}"
: "${FLAGSMITH_ADMIN_API_TOKEN:?Set Flagsmith Admin API token for one-time feature bootstrap}"
: "${FLAGSMITH_PROJECT:?Set Flagsmith project name or ID}"
: "${NUDGEBEE_AGENT_KEY:?Set NUDGEBEE_AGENT_KEY from NudgeBee > Admin > Integrations > Kubernetes Clusters}"
: "${GEOCODING_API_KEY:?Set restricted Google Geocoding API key}"
REGION="${REGION:-asia-south1}"
ZONE="${ZONE:-${REGION}-a}"
CLUSTER="${CLUSTER:-pehle-aap}"
NAMESPACE="pehle-aap"
BUCKET="${GCS_BUCKET:-${PROJECT_ID}-pehle-aap-media}"
IMAGE_TAG="${IMAGE_TAG:-$(date +%Y%m%d%H%M%S)}"

command -v gcloud >/dev/null || { echo 'Install Google Cloud CLI first'; exit 1; }
command -v kubectl >/dev/null || { echo 'Install kubectl first'; exit 1; }
command -v helm >/dev/null || { echo 'Install Helm 3 first'; exit 1; }
command -v docker >/dev/null || { echo 'Install Docker first'; exit 1; }

printf '\n[1/10] Configure project and enable APIs\n'
gcloud config set project "$PROJECT_ID"
gcloud services enable container.googleapis.com artifactregistry.googleapis.com cloudbuild.googleapis.com storage.googleapis.com compute.googleapis.com dns.googleapis.com

printf '\n[2/10] Create Artifact Registry, GCS bucket and GKE Standard cluster\n'
gcloud artifacts repositories describe pehle-aap --location "$REGION" >/dev/null 2>&1 || \
  gcloud artifacts repositories create pehle-aap --repository-format=docker --location "$REGION"
gcloud storage buckets describe "gs://${BUCKET}" >/dev/null 2>&1 || \
  gcloud storage buckets create "gs://${BUCKET}" --location "$REGION" --uniform-bucket-level-access
# Private bucket; app accesses it using the GKE node service account.
PROJECT_NUMBER="$(gcloud projects describe "$PROJECT_ID" --format='value(projectNumber)')"
COMPUTE_SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"
gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:${COMPUTE_SA}" --role=roles/storage.objectAdmin --quiet >/dev/null
if ! gcloud container clusters describe "$CLUSTER" --zone "$ZONE" >/dev/null 2>&1; then
  gcloud container clusters create "$CLUSTER" --zone "$ZONE" --num-nodes="${NODE_COUNT:-2}" \
    --machine-type="${MACHINE_TYPE:-e2-standard-4}" --disk-size=50 \
    --workload-pool="${PROJECT_ID}.svc.id.goog" --release-channel=regular \
    --enable-ip-alias --enable-autorepair
fi
gcloud container clusters get-credentials "$CLUSTER" --zone "$ZONE"
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

printf '\n[3/10] Install PostgreSQL operator and create database\n'
helm repo add cnpg https://cloudnative-pg.github.io/charts >/dev/null 2>&1 || true
helm repo update
helm upgrade --install cnpg cnpg/cloudnative-pg -n cnpg-system --create-namespace --wait
kubectl apply -f k8s/postgres.yaml
kubectl -n "$NAMESPACE" wait --for=condition=Ready cluster/pehle-db --timeout=900s

printf '\n[4/10] Bootstrap Flagsmith feature keys and create application secrets\n'
# Admin token is used only here; the runtime receives the server-side environment key.
export FLAGSMITH_API_KEY="$FLAGSMITH_ADMIN_API_TOKEN"
export FLAGSMITH_PROJECT
FLAGS_IMAGE=ghcr.io/flagsmith/flagsmith-cli
create_flag() {
  local key="$1" value="$2" enabled="$3"
  if docker run --rm -e FLAGSMITH_API_KEY -e FLAGSMITH_PROJECT "$FLAGS_IMAGE" feature get "$key" --project "$FLAGSMITH_PROJECT" --json >/dev/null 2>&1; then
    echo "Flagsmith feature exists: $key"
  else
    local args=(feature create "$key" --project "$FLAGSMITH_PROJECT" --value "$value" --yes --no-input)
    [[ "$enabled" == "true" ]] && args+=(--enabled)
    docker run --rm -e FLAGSMITH_API_KEY -e FLAGSMITH_PROJECT "$FLAGS_IMAGE" "${args[@]}"
  fi
}
create_flag low_bandwidth_mode false false
create_flag photo_upload_enabled true true
create_flag upi_button true true
create_flag push_notifications true true
create_flag pinky_bua true true
create_flag voice_announcements true true
create_flag risk_bar_voice false false
create_flag queue_due_minutes '{"regular":45,"elder":15,"leave_buffer":10}' true
create_flag stage_time_seed '{"a":30,"b":8}' true
create_flag poll_interval_s 20 true
create_flag plate_margin 0.10 true
create_flag expense_category_threshold 0.8 true
create_flag thank_you_variant photos-first true
unset FLAGSMITH_API_KEY
kubectl -n "$NAMESPACE" create secret generic app-secrets \
  --from-literal=SARVAM_API_KEY="$SARVAM_API_KEY" \
  --from-literal=FLAGSMITH_SERVER_KEY="$FLAGSMITH_SERVER_KEY" \
  --from-literal=GEOCODING_API_KEY="$GEOCODING_API_KEY" \
  --from-literal=GCS_BUCKET="$BUCKET" \
  --from-literal=APP_NAME=pehle-aap-api \
  --dry-run=client -o yaml | kubectl apply -f -

printf '\n[5/10] Build and deploy HTML + Node.js API\n'
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/pehle-aap/web:${IMAGE_TAG}"
gcloud builds submit --tag "$IMAGE" .
sed "s|IMAGE_PLACEHOLDER|$IMAGE|g" k8s/deployment.yaml | kubectl apply -f -

printf '\n[6/10] Run schema migration and seed dummy wedding data\n'
# Wait for the CNPG application secret created by the operator.
for i in $(seq 1 90); do kubectl -n "$NAMESPACE" get secret pehle-db-app >/dev/null 2>&1 && break; sleep 5; done
kubectl -n "$NAMESPACE" get secret pehle-db-app >/dev/null
for job in pehle-aap-migrate pehle-aap-seed; do kubectl -n "$NAMESPACE" delete job "$job" --ignore-not-found >/dev/null; done
kubectl -n "$NAMESPACE" delete job pehle-aap-migrate pehle-aap-seed --ignore-not-found >/dev/null
for JOB in pehle-aap-migrate pehle-aap-seed; do
  SCRIPT="src/migrate.js"; [[ "$JOB" == "pehle-aap-seed" ]] && SCRIPT="src/seed.js"
  cat <<EOF | kubectl apply -f -
apiVersion: batch/v1
kind: Job
metadata:
  name: ${JOB}
  namespace: ${NAMESPACE}
spec:
  backoffLimit: 2
  template:
    spec:
      restartPolicy: Never
      containers:
      - name: runner
        image: ${IMAGE}
        command: ["node", "${SCRIPT}"]
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: pehle-db-app
              key: uri
EOF
  kubectl -n "$NAMESPACE" wait --for=condition=complete "job/${JOB}" --timeout=600s
  kubectl -n "$NAMESPACE" logs "job/${JOB}"
done

printf '\n[7/10] Install Prometheus and NudgeBee agent\n'
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts >/dev/null 2>&1 || true
helm repo add nudgebee-agent https://nudgebee.github.io/k8s-agent/ >/dev/null 2>&1 || true
helm repo update
helm upgrade --install nudgebee-prometheus prometheus-community/kube-prometheus-stack \
  --namespace nudgebee-agent --create-namespace --set nodeExporter.enabled=true \
  --set alertmanager.enabled=true --set kubeStateMetrics.enabled=true \
  -f https://raw.githubusercontent.com/nudgebee/k8s-agent/main/kube-prometheus-stack-values.yaml --wait --timeout 15m
kubectl apply -f k8s/servicemonitor.yaml
kubectl apply -f k8s/prometheusrule.yaml
helm upgrade --install nudgebee-agent nudgebee-agent/nudgebee-agent \
  --namespace nudgebee-agent --create-namespace \
  --set-string runner.nudgebee.auth_secret_key="$NUDGEBEE_AGENT_KEY" \
  --set-string globalConfig.prometheus_url="http://nudgebee-prometheus-kube-p-prometheus.nudgebee-agent.svc:9090" \
  --set nodeAgent.podmonitor.enabled=false --wait --timeout 15m

printf '\n[8/10] Configure HTTPS endpoint\n'
IP_NAME=pehle-aap-ip
 gcloud compute addresses describe "$IP_NAME" --global >/dev/null 2>&1 || gcloud compute addresses create "$IP_NAME" --global
IP="$(gcloud compute addresses describe "$IP_NAME" --global --format='value(address)')"
cat <<EOF | kubectl apply -f -
apiVersion: networking.gke.io/v1
kind: ManagedCertificate
metadata:
  name: pehle-aap-cert
  namespace: ${NAMESPACE}
spec:
  domains:
  - ${APP_DOMAIN}
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: pehle-aap-ingress
  namespace: ${NAMESPACE}
  annotations:
    kubernetes.io/ingress.class: gce
    kubernetes.io/ingress.global-static-ip-name: ${IP_NAME}
    networking.gke.io/managed-certificates: pehle-aap-cert
spec:
  rules:
  - host: ${APP_DOMAIN}
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: web
            port:
              number: 80
EOF
if [[ -n "${DNS_ZONE:-}" ]]; then
  gcloud dns record-sets transaction start --zone="$DNS_ZONE"
  gcloud dns record-sets transaction remove --zone="$DNS_ZONE" --name="${APP_DOMAIN}." --type=A --ttl=300 "$(gcloud dns record-sets list --zone="$DNS_ZONE" --name="${APP_DOMAIN}." --type=A --format='value(rrdatas)' 2>/dev/null || true)" 2>/dev/null || true
  gcloud dns record-sets transaction add --zone="$DNS_ZONE" --name="${APP_DOMAIN}." --type=A --ttl=300 "$IP"
  gcloud dns record-sets transaction execute --zone="$DNS_ZONE"
fi

printf '\n[9/10] Wait for application rollout\n'
kubectl -n "$NAMESPACE" rollout status deployment/web --timeout=600s
kubectl -n "$NAMESPACE" get pods

printf '\n[10/10] Deployment summary\n'
echo "Reserved IP: ${IP}"
echo "DNS: point ${APP_DOMAIN} A record to ${IP} (if DNS_ZONE was not supplied)."
echo "HTTPS: Google ManagedCertificate will provision after DNS resolves; allow up to 60 minutes."
echo "App: https://${APP_DOMAIN}"
echo "Demo access keys (change before production): demo-couple-key, demo-team-key, demo-vendor-key, demo-guest-key"
echo "Flagsmith: create the feature keys listed in docs/DEPLOYMENT_GUIDE.md in your project/environment."
echo "NudgeBee: verify cluster and Watchdog alert in app.nudgebee.com."
